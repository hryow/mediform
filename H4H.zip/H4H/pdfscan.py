import PyPDF2
import re

fileName = "testrun.pdf"
doc = PyPDF2.PdfReader(fileName)

pages = len(doc.pages)

for i in range(pages):
    currentPage = doc.pages[i]
    text = currentPage.extract_text()
    print(text)